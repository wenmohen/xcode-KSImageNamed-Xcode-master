//
//  DVTTextCompletionSession+KSImageNamed.h
//  KSImageNamed
//
//  Created by Kent Sutherland on 11/1/15.
//
//

#import "XcodeMisc.h"

@interface DVTTextCompletionSession (KSImageNamed)

@end
