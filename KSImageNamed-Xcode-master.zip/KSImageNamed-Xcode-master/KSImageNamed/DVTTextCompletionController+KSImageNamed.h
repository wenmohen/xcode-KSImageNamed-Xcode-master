//
//  DVTTextCompletionController+KSImageNamed.h
//  KSImageNamed
//
//  Created by Kent Sutherland on 1/22/13.
//
//

#import "XcodeMisc.h"

@interface DVTTextCompletionController (KSImageNamed)

@end
