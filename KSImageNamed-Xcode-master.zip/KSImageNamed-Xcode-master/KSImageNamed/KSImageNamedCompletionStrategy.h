//
//  KSImageNamedCompletionStrategy.h
//  KSImageNamed
//
//  Created by Kent Sutherland on 10/3/15.
//
//

#import <Foundation/Foundation.h>
#import "XcodeMisc.h"

@interface KSImageNamedCompletionStrategy : DVTTextCompletionStrategy

@end
